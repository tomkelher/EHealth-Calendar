﻿using System.Text;
using System;

namespace Calendar
{
    public class CalendarFunctions
    {
        string[] taken;

        public CalendarFunctions()
        {

        }

        public void addTaak(DateTime date, String taak)
        {

        }

        public void removeTaak(DateTime date, int taakID)
        {

        }
        public string[] getTaken(DateTime date)
        {
            return taken;
        }



    }
}