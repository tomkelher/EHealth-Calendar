﻿Thank you for installing i18n.

Please refer to the following URL for instructions on enabling i18n in your project:

https://github.com/turquoiseowl/i18n#project-configuration
